<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jquerymobile/1.4.5/jquery.mobile.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquerymobile/1.4.5/jquery.mobile.min.js"></script>

<script type="text/javascript" src="./js/js.storage.min.js"></script> 
<script src="./ipadpos/<?php echo $pos;?>.js"></script>
<script type="text/javascript" src="./js/jquery.numpad.js"></script>
<link rel="stylesheet" href="./js/jquery.numpad.css">
<link rel="stylesheet" href="./ipadpos/styles.css">