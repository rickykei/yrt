	
	

	<div id="page_footage_div2">
	  
		<div class="ui-block-a">
		<input type="text"  name="quickinput" id="quickinput" placeholder="貨品編號" >
		<input type="hidden" id="quickinput-id"/>
		<p id="quickinput-description"></p>
		</div>
		
		<div class="ui-block-b">
		<a class="ui-button ui-widget ui-corner-all quickinput" href="" rel="external"  data-inline="true" >快速輸入</a> 
		</div>
		
		
		<div class="ui-block-c">
				<input type="text"  name="mem_id" id="mem_id" placeholder="客戶編號" >
		</div>
		
		<div class="ui-block-d">
		<a class="ui-button ui-widget ui-corner-all quickinput_memid" href="" rel="external"  data-inline="true" >客戶編號</a> 
		</div>
	</div>	 	
		 
	<div  id="quick_mem_add_div">
			<div class="ui-block-a">
				<input type="text"  name="mem_add" id="mem_add" placeholder="地址"  >
			</div>
			<div class="ui-block-b">
				<a class="ui-button ui-widget ui-corner-all quickinput_memadd" href="" rel="external"  data-inline="true" >地址</a> 
			</div>
		
	</div>
	